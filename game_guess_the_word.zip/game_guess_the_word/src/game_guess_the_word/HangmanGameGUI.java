/** 
 * Hangman Game made by Idrees Dehistani (Student ID: 200201841)
 * 
 * This code creates a Hangman game with a graphical user interface. 
 * The game randomly chooses a word, and the player tries to guess the word by entering letters.
 * Players have a limited number of lives, and the computer provides feedback on correct and incorrect guesses.
 * 
 * CENG 301: Analysis of Algorithms
 */

package game_guess_the_word;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;



public class HangmanGameGUI extends JFrame {
    private JLabel wordLabel, statusLabel;
    private JTextField guessField;
    private JButton guessButton;

    private String secretWord;
    private Set<Character> wordLetters;
    private Set<Character> guessedLetters;
    private int remainingLives;

    /**
     * Constructor to set up the initial GUI components and start the game.
     */
    
    public HangmanGameGUI() {
        // Set up the main window
        setTitle("Hangman_Game");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1));


        wordLabel = new JLabel("");
        statusLabel = new JLabel("Welcome to Hangman!, Try to guess the word.");
        guessField = new JTextField();
        guessButton = new JButton("Enter");


        guessButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkGuess();
            }
        });

        
        add(wordLabel);
        add(statusLabel);
        add(guessField);
        add(guessButton);


        startGame();
    }

    /**
     * Initialize the game by setting up the following functions and methods: 
     * the secret word, word letters, guessed letters, and remaining lives.
     */
    
    private void startGame() {

        secretWord = getValidWord();
        wordLetters = new HashSet<>();
        guessedLetters = new HashSet<>();
        remainingLives = 8;

        for (char letter : secretWord.toCharArray()) {
            wordLetters.add(letter);
        }


        updateWordLabel();
    }

    /**
     * Choose a valid word for the game.
     *
     * return A valid word for the game.
     */
    
    private String getValidWord() {
        // Array of words for the game
        String[] words = {"java","exams","hard" ,"food","python", "hangman", "computer", "programming", "Apple", "Professor", "Ostim", "Class", "Mother", "Father", "classroom"};
        

        Random random = new Random();
        String word = words[random.nextInt(words.length)];
        while (word.contains("_") || word.contains(" ")) {
            word = words[random.nextInt(words.length)];
        }

        return word.toUpperCase();
    }

    /**
     * Check the Player's guess and update the game state accordingly.
     */
    
    private void checkGuess() {
        
        String userGuess = guessField.getText().toUpperCase();

        
        if (userGuess.length() == 1 && Character.isLetter(userGuess.charAt(0))) {
            char guessedLetter = userGuess.charAt(0);


            if (!guessedLetters.contains(guessedLetter)) {
                guessedLetters.add(guessedLetter);


                if (wordLetters.contains(guessedLetter)) {

                    updateWordLabel();
                    if (isWordGuessed()) {
                        statusLabel.setText("Congratulations! You guessed it right!");
                        disableGuessing();
                    } else {
                        statusLabel.setText("Good guess! Keep going.");
                    }
                } else {

                    remainingLives--;
                    updateWordLabel();
                    statusLabel.setText("Incorrect guess. Lives left: " + remainingLives);
                    if (remainingLives == 0) {
                        statusLabel.setText("Sorry, you've run out of lives. The word was: " + secretWord);
                        disableGuessing();
                    }
                }
            } else {
                statusLabel.setText("You already guessed that letter. Try a different one.");
            }
        } else {
            statusLabel.setText("Please enter a valid letter.");
        }

        
        guessField.setText("");
    }

    /**
     * Update the displayed word depending on guessed letters.
     */
    
    private void updateWordLabel() {

        StringBuilder displayWord = new StringBuilder();
        for (char letter : secretWord.toCharArray()) {
            if (guessedLetters.contains(letter) || !Character.isLetter(letter)) {
                displayWord.append(letter);
            } else {
                displayWord.append("_");
            }
        }
        wordLabel.setText(displayWord.toString());
    }

    
    private boolean isWordGuessed() {

        for (char letter : wordLetters) {
            if (!guessedLetters.contains(letter)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Disable guessing by disabling the guessField and guessButton.
     */
    
    private void disableGuessing() {
        guessField.setEnabled(false);
        guessButton.setEnabled(false);
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new HangmanGameGUI().setVisible(true);
            }
        });
    }
}
